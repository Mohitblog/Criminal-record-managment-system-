# Crime-Record-Management-System-using-Java
This system provides a comprehensive framework for the digital management of criminal records. It was created using the Java programming language, the Swing framework for the graphical user interface, and an integration with a MySQL database as backend. User authentication, data entry, search & retrieval , updation and deletion of the records, are some of the key features of this CRMS.
[Shreksta -crms-  Project Report.pdf](https://github.com/Shreksta/Crime-Record-Management-System-using-Java/files/13797305/Shreksta.-crms-.Project.Report.pdf)
